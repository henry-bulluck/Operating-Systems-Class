#!/bin/sh
find "$1" -name "*.$2" -exec realpath {} \;

