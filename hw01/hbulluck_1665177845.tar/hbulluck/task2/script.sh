#!/bin/sh
find "$1" -name "*.txt" -exec cat {} \;


