gcc -o task1 task1.c
gcc -o task2 task2.c
gcc -o task3 task3.c
